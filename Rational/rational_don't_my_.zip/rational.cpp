#include "rational.h"

Rational::Rational() : a_(0), b_(1) {
}
Rational::Rational(int64_t x) : a_(x), b_(1) {
}
Rational::Rational(int64_t x, int64_t y) : a_(x), b_(y) {
  if (y == 0) {
    throw RationalDivisionByZero{};
  }
  Shorten();
}
void Rational::Shorten() {
  if (b_ < 0) {
    a_ *= -1;
    b_ *= -1;
  }
  int64_t gcd = std::gcd(a_, b_);
  a_ /= gcd;
  b_ /= gcd;
}
int64_t Rational::GetNumerator() const {
  return a_;
}
int64_t Rational::GetDenominator() const {
  return b_;
}
void Rational::SetNumerator(int64_t t) {
  a_ = t;
  Shorten();
}
void Rational::SetDenominator(int64_t t) {
  if (t == 0) {
    throw RationalDivisionByZero{};
  }
  b_ = t;
  Shorten();
}
Rational& Rational::operator+=(const Rational& y) {
  a_ *= y.b_;
  a_ += y.a_ * b_;
  b_ *= y.b_;
  Shorten();
  return *this;
}
Rational& Rational::operator-=(const Rational& y) {
  a_ *= y.b_;
  a_ -= y.a_ * b_;
  b_ *= y.b_;
  Shorten();
  return *this;
}
Rational& Rational::operator*=(const Rational& y) {
  a_ *= y.a_;
  b_ *= y.b_;
  Shorten();
  return *this;
}
Rational& Rational::operator/=(const Rational& y) {
  a_ *= y.b_;
  b_ *= y.a_;
  Shorten();
  return *this;
}
Rational Rational::operator+() const {
  return *this;
}
Rational Rational::operator-() const {
  Rational t = *this;
  t *= -1;
  return t;
}
Rational& Rational::operator++() {
  *this += 1;
  return *this;
}
Rational Rational::operator++(int) {
  Rational t = *this;
  *this += 1;
  return t;
}
Rational& Rational::operator--() {
  *this -= 1;
  return *this;
}
Rational Rational::operator--(int) {
  Rational t = *this;
  *this -= 1;
  return t;
}
Rational operator+(const Rational& x, const Rational& y) {
  return Rational(x.a_ * y.b_ + y.a_ * x.b_, x.b_ * y.b_);
}
Rational operator-(const Rational& x, const Rational& y) {
  return Rational(x.a_ * y.b_ - y.a_ * x.b_, x.b_ * y.b_);
}
Rational operator*(const Rational& x, const Rational& y) {
  return Rational(x.a_ * y.a_, x.b_ * y.b_);
}
Rational operator/(const Rational& x, const Rational& y) {
  return Rational(x.a_ * y.b_, x.b_ * y.a_);
}
bool operator<(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ < y.a_ * x.b_);
}
bool operator<=(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ <= y.a_ * x.b_);
}
bool operator>(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ > y.a_ * x.b_);
}
bool operator>=(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ >= y.a_ * x.b_);
}
bool operator==(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ == y.a_ * x.b_);
}
bool operator!=(const Rational& x, const Rational& y) {
  return (x.a_ * y.b_ != y.a_ * x.b_);
}
std::ostream& operator<<(std::ostream& out, const Rational& y) {
  if (y.b_ != 1) {
    out << y.a_ << "/" << y.b_;
  } else {
    out << y.a_;
  }
  return out;
}
std::istream& operator>>(std::istream& in, Rational& y) {
  y.a_ = 1;
  in >> y.a_;
  char drob = 0;
  if (in.peek() != '/') {
    y.b_ = 1;
  } else {
    in >> drob >> y.b_;
    y.Shorten();
  }
  return in;
}