#pragma once

#include <cstdint>
#include <numeric>
#include <iostream>
#include <stdexcept>

class RationalDivisionByZero : public std::runtime_error {
 public:
  RationalDivisionByZero() : std::runtime_error("RationalDivisionByZero") {
  }
};

class Rational {
  int64_t a_, b_;

 public:
  Rational();

  Rational(int64_t);  // NOLINT

  Rational(int64_t, int64_t);

  void Shorten();

  int64_t GetNumerator() const;

  int64_t GetDenominator() const;

  void SetNumerator(int64_t);

  void SetDenominator(int64_t);

  Rational& operator+=(const Rational&);

  Rational& operator-=(const Rational&);

  Rational& operator*=(const Rational&);

  Rational& operator/=(const Rational&);

  Rational operator+() const;

  Rational operator-() const;

  Rational& operator++();

  Rational operator++(int);

  Rational& operator--();

  Rational operator--(int);

  friend Rational operator+(const Rational&, const Rational&);

  friend Rational operator-(const Rational&, const Rational&);

  friend Rational operator*(const Rational&, const Rational&);

  friend Rational operator/(const Rational&, const Rational&);

  friend bool operator<(const Rational&, const Rational&);

  friend bool operator<=(const Rational&, const Rational&);

  friend bool operator>(const Rational&, const Rational&);

  friend bool operator>=(const Rational&, const Rational&);

  friend bool operator==(const Rational&, const Rational&);

  friend bool operator!=(const Rational&, const Rational&);

  friend std::ostream& operator<<(std::ostream&, const Rational&);

  friend std::istream& operator>>(std::istream&, Rational&);
};